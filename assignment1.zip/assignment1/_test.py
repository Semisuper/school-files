import orders
import pytest


def test_drink_getters():
    drink1 = orders.Drink("large")
    drink1.set_base("sbrite")
    drink1.set_flavors(["lemon", "cherry", "mint"])

    assert drink1.get_base() == "sbrite"
    assert drink1.get_flavors().__contains__("cherry")
    assert drink1.get_flavors().__contains__("mint")
    assert drink1.get_flavors().__contains__("lemon")
    assert drink1.get_num_flavors() == 3


def test_drink_cost():
    drink1 = orders.Drink("large")
    drink1.set_base("sbrite")
    drink1.set_flavors(["lemon", "cherry", "mint"])
    assert drink1.get_total() == 2.50


def test_base_error():
    with pytest.raises(ValueError) as excinfo:
        drink1 = orders.Drink("large")
        drink1.set_base("sprote")

    assert "Pick a proper base from" in str(excinfo.value)


def test_flavor_error():
    with pytest.raises(ValueError) as excinfo:
        drink1 = orders.Drink("large")
        drink1.set_base("sbrite")
        drink1.set_flavors(["grape", "cherry", "mint"])
    assert "Pick a proper flavor from" in str(excinfo.value)

    with pytest.raises(ValueError) as excinfo:
        drink1 = orders.Drink("large")
        drink1.set_base("sbrite")
        drink1.add_flavor("grape")
    assert "Pick a proper flavor from" in str(excinfo.value)


def test_size_error():
    with pytest.raises(ValueError) as excinfo:
        drink1 = orders.Drink("large")
        drink1.set_size("beeg")
    assert "Invalid size:" in str(excinfo.value)


def test_single_flavor():
    drink1 = orders.Drink("large")
    drink1.set_base("sbrite")
    drink1.add_flavor("lemon")

    assert drink1.get_flavors() == ["lemon"]


def test_order_getters():
    drink1 = orders.Drink("large")
    drink1.set_base("sbrite")
    drink1.add_flavor("lemon")

    drink2 = orders.Drink("small")
    drink2.set_base("hill fog")
    drink2.add_flavor("strawberry")

    drink3 = orders.Drink("medium")
    drink3.set_base("pokecola")
    drink3.add_flavor("mint")

    order1 = orders.Order()
    order1.add_item(drink1)
    order1.add_item(drink2)
    order1.add_item(drink3)

    assert order1.get_items().__contains__(drink1)
    assert order1.get_items().__contains__(drink2)
    assert order1.get_items().__contains__(drink3)
    assert order1.get_total() == 5.75


def test_order_class():
    drink1 = orders.Drink("large")
    drink1.set_base("sbrite")
    drink1.add_flavor("lemon")

    drink2 = orders.Drink("small")
    drink2.set_base("hill fog")
    drink2.add_flavor("strawberry")

    drink3 = orders.Drink("medium")
    drink3.set_base("pokecola")
    drink3.add_flavor("mint")

    order1 = orders.Order()
    order1.add_item(drink1)
    order1.add_item(drink2)
    order1.add_item(drink3)
    assert order1.get_receipt().__contains__("number_drinks")


def test_order_errors():
    with pytest.raises(ValueError) as excinfo:
        drink1 = orders.Drink("large")
        drink1.set_base("sbrite")
        drink1.add_flavor("lemon")
        badobject = "drink"

        order1 = orders.Order()
        order1.add_item(drink1)
        order1.add_item(badobject)
    assert "you can only add drinks to this order" in str(excinfo.value)
    with pytest.raises(IndexError) as excinfo:
        drink1 = orders.Drink("large")
        drink1.set_base("sbrite")
        drink1.add_flavor("lemon")

        drink2 = orders.Drink("small")
        drink2.set_base("hill fog")
        drink2.add_flavor("strawberry")

        order2 = orders.Order()
        order2.add_item(drink1)
        order2.add_item(drink2)

        order2.remove_item(2)
    assert "Invalid, cannot remove" in str(excinfo.value)


def test_order_remove():
    drink1 = orders.Drink("large")
    drink1.set_base("sbrite")
    drink1.add_flavor("lemon")

    drink2 = orders.Drink("small")
    drink2.set_base("hill fog")
    drink2.add_flavor("strawberry")

    order1 = orders.Order()
    order1.add_item(drink1)
    order1.add_item(drink2)
    order1.remove_item(0)
    assert len(order1.get_items()) == 1
