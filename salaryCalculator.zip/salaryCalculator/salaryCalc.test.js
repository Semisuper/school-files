import { paySalary } from "./salaryCalc"
import {vi, beforeEach, it, expect} from "vitest"
import { Window } from 'happy-dom'
import fs from 'fs';
import path from 'path';

const htmlDocPath = path.join(process.cwd(), 'salaryCalc.html');
const htmlDocumentContent = fs.readFileSync(htmlDocPath).toString();

const window = new Window();
const document = window.document;
vi.stubGlobal('document', document)

beforeEach(() => {
	document.body.innerHTML = '';
	document.write(htmlDocumentContent);
})

it("should return 'employee gross pay: 300' at 30 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 30

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 300")
})

it("should return 'employee gross pay: 415' at 41 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 41

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 415")
})

it("should return 'employee gross pay: 0' at 0 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 0

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 0")
})

it("should return 'employee gross pay: 400' at 40 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 40

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 400")
})

it("should return 'employee gross pay: 925' at 75 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 75

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 925")
})

it("Should return the name element as 'Employee name: [inputted name]'", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 30

    paySalary()
    const displayName = document.getElementById("name").innerHTML
    expect(displayName).toBe("Employee Name: dave")
})
