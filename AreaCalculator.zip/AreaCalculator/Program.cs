﻿Console.WriteLine("Enter Height");
int UserHeight = int.Parse(Console.ReadLine());
Console.WriteLine("Enter Length");
int UserLength = int.Parse(Console.ReadLine());

int findArea(int height, int length){
    int area = height * length;
    return area;
}

int FinalCalc = findArea(UserHeight, UserLength);
Console.WriteLine("The area of your rectangle is " + FinalCalc);