function appleCheckout(quantity, price) {
	return quantity * price
}
module.exports = appleCheckout