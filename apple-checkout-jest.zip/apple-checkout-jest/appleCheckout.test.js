const appleCheckout = require('./appleCheckout');

describe("checkout Test cases", () => {
	test("buying one apple at 50 cents costs 50 cents", () => {
		expect(appleCheckout(1, 0.5)).toBe(0.5)
	});
	
	test("buying three apples at 50 cents costs $1.50", () => {
		expect(appleCheckout(3, 0.5)).toBe(1.5)
	});
	
	test("buying zero apples at 50 cents costs nothing", () => {
		expect(appleCheckout(0, 0.5)).toBe(0)
	});
	
	test("buying 12 apples at $1 costs $12", () => {
		expect(appleCheckout(12, 1)).toBe(12)
	});
	
});