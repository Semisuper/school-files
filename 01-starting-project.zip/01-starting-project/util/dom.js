export function showError(message) {
  const errorContainerElement = document.getElementById('errors');
  const errorMessageElement = document.createElement('p');
  errorMessageElement.textContent = message;
  if (message === '!clear') { //only executes if the message is !clear
    return errorContainerElement.innerHTML = ''; //uses the return keyword to skip the append line if this line is excecuted
  };
  errorContainerElement.append(errorMessageElement);
};
