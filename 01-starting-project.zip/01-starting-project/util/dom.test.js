import fs from 'fs';
import path from 'path';

import { vi, it, expect, beforeEach } from 'vitest';
import { Window } from 'happy-dom'
import { showError } from './dom';

const htmlDocPath = path.join(process.cwd(), 'index.html');
const htmlDocumentContent = fs.readFileSync(htmlDocPath).toString();

const window = new Window();
const document = window.document;
vi.stubGlobal('document', document)

beforeEach(() => {
	document.body.innerHTML = '';
	document.write(htmlDocumentContent);
})

it('should add an error paragraph to the id="errors" element', () => {
	showError('jeffery')

	const errorsEl = document.getElementById('errors')
	const errorParagraph = errorsEl.firstElementChild;

	expect(errorParagraph).not.toBeNull()
});

it('should not contain an error paragraph initially', () => {

	const errorsEl = document.getElementById('errors')
	const errorParagraph = errorsEl.firstElementChild;

	expect(errorParagraph).toBeNull()
});

it('should output the provided message in the error paragraph', () => {
	const testErrorMessage = 'test'
	showError(testErrorMessage)

	const errorsEl = document.getElementById('errors')
	const errorParagraph = errorsEl.firstElementChild;

	expect(errorParagraph.textContent).toBe(testErrorMessage)
})

it('should add 3 <p> elements to the id="errors" element', () => { //added this test and changed the functionality of the showError function to not clear itself during each call
	showError('test1')
	showError('test2')
	showError('test3')

	const errorsEl = document.getElementById('errors')
	const errorParagraphs = errorsEl.childElementCount
	expect(errorParagraphs).toBe(3)
})

it('should clear all child elements from the id="errors" element when !clear is passed as the message', () => { //added this test and channged the functionality of the showError function to clear itself if !clear was passed as the message
	showError('test')
	showError('test2')

	const errorsEl = document.getElementById('errors')
	let errorParagraph = errorsEl.firstElementChild;

	expect(errorParagraph).not.toBeNull()

	showError('!clear')
	errorParagraph = errorsEl.firstElementChild

	expect(errorParagraph).toBeNull()
})