using Shapes3D;
class FinalAssignment {
    public static readonly Dictionary<string, Type> shapeMap = new(){
        {"cube", typeof(Cube)},
        {"cuboid", typeof(Cuboid)},
        {"cylinder", typeof(Cylinder)},
        {"sphere", typeof(Sphere)},
        {"prism", typeof(Prism)}
    };
    public static class Solver {
        public static void Main(String[] args) {
            if (args.Length != 1) {
                Console.WriteLine("Incorrect argument number. Requires 1.");
                return;
            }
            if (!File.Exists(args[0])) {
                Console.WriteLine("That file does not exist!");
                return;
            }
            List<Shape3D> shapeList = [];
            double total = 0.0;
            foreach(string line in File.ReadAllLines(args[0])) {
                string[] linepieces = line.Split(',');
                string code = linepieces[0];
                double[] lineSet = linepieces[1..].Select(double.Parse).ToArray();
                if (code == "volume") {
                    double totalVolume = 0.0;
                    totalVolume += shapeList.Select((shape) => shape.volume).Sum();
                    total += totalVolume * lineSet[0];
                    shapeList.Clear();
                } else if (code == "area") {
                    double totalArea = 0.0;
                    totalArea += shapeList.Select((shape) => shape.area).Sum();
                    total += totalArea * lineSet[0];
                    shapeList.Clear();
                } else {
                    Shape3D shape = (Shape3D)shapeMap[code].GetConstructors()[0].Invoke(
                        lineSet.Cast<object>().ToArray()
                    );

                    shapeList.Add(shape);
                }
            };
            Console.WriteLine($"the sum of measurements is {total:N}");
        }
    }
}