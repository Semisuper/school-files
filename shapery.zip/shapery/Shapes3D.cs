using Shapes;

namespace Shapes3D;

public abstract class Shape3D {
    private double _area;
    public double area{
        get {return _area;}
        protected set {_area = value;}
    }
    private double _volume;
    public double volume{
        get {return _volume;}
        protected set {_volume = value;}
    }
}
public class Cuboid : Shape3D {
    private double _width;
    public double width {
        get {return _width;}
        private set {_width = value;}
    }
    private double _height;
    public double height {
        get {return _height;}
        private set {_height = value;}
    }
    private double _depth;
    public double depth {
        get {return _depth;}
        private set {_depth = value;}
    }

    public Cuboid(double width, double height, double depth) {
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.volume = width * height * depth;
        this.area = (2 * height * depth) + (2 * width * depth) + (2 * height * width);
    }
}

class Cube : Cuboid {
    public Cube(double sideLength) : base(sideLength, sideLength, sideLength) {}
}

class Cylinder : Shape3D {
    private double _radius;
    public double radius {
        get {return _radius;}
        private set {_radius = value;}
    }
    private double _height;
    public double height {
        get {return _height;}
        private set {_height = value;}
    }
    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
        this.area = (2 * Math.PI * radius * radius) + (2 * Math.PI * radius * height);
        this.volume = (Math.PI * radius * radius) * height;
    }
}

class Sphere : Shape3D {
    private double _radius;
    public double radius {
        get {return _radius;}
        private set {_radius = value;}
    }
    public Sphere(double radius) {
        this.radius = radius;
        this.area = 4 * Math.PI * radius * radius;
        this.volume = (4.0/3.0) * Math.PI * Math.Pow(radius, 3);
    }
}

class Prism : Shape3D {
    private double _sideLength;
    public double sideLength {
        get {return _sideLength;}
        private set {_sideLength = value;}
    }
    private double _faces;
    public double faces {
        get {return _faces;}
        private set {_faces = value;}
    }
    private double _height;
    public double height {
        get {return _height;}
        private set {_height = value;}
    }
    public Prism(double sideLength, double faces, double height) {
        this.sideLength = sideLength;
        this.faces = faces;
        this.height = height;
        Polygon pbase = new Polygon(sideLength, (int)faces);
        this.area = 2 * pbase.Area() + (pbase.Perimeter() * height);
        this.volume = pbase.Area() * height;
    }
}
/*
This makes our total list:
Shape Name 	                Shape Code 	Measurements
Cuboid (rectangular prism) 	cuboid 	double width, double height, double depth
Cube (child of cuboid) 	cube 	double sideLength
Cylinder 	cylinder 	double radius, double height
Sphere 	sphere 	double radius
n-gonal prism 	prism 	double sideLength, int faces, double height
*/