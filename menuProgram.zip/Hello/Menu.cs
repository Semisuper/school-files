public class Menu {
    MenuItem [] menuItems;
    DateTime updated;    
    public Menu(MenuItem [] menuItems, DateTime updated) {
        this.menuItems = menuItems;
        this.updated = updated;
    }
    public void display() {
        Console.WriteLine("Last Updated:");
        Console.WriteLine(updated);
        foreach(MenuItem item in menuItems){
            Console.WriteLine("");
            item.display();
        }
    }
}