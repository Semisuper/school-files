public static class MainProgram {
    public static void Main(string [] args) {
        Menu menu = new Menu(
            new MenuItem [] {
                new MenuItem("ravioli", 10.10, "entree", false), new MenuItem("key lime pie", 5.23, "dessert", true), new MenuItem("stuffed jalapenos", 7.10, "appetizer", false),
            },
            DateTime.Now
        );
        menu.display();
    }
}