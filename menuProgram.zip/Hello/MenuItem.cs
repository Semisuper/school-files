﻿// See https://aka.ms/new-console-template for more informationS
public class MenuItem {
    string name;
    double price;
    string category;
    bool isnew;
    public MenuItem(string name, double price, string category, bool isnew) {
        this.name = name;
        this.price = price;
        this.category = category;
        this.isnew = isnew;
    }
    public void display() {
        Console.WriteLine(category);
        Console.WriteLine(name + " price: " + price);
        if(isnew == true) {
            Console.WriteLine("NEW!");
        }
    }
}