﻿int countCharacters(string Line, char Find) {
    int CharsFound = 0;
    char[] StringCheck = Line.ToCharArray(); //Converts the inputted string into a iterable array where each character is a seperate element.
    for(int i = 0; i < StringCheck.Length; i++){
        if (Char.ToUpper(StringCheck[i]) == Find){ //Checks if each character in the stringCheck array is equal to the find character.
            CharsFound++;
        }
    }
    return CharsFound;
}

Console.WriteLine("Input a string");
string UserString = Console.ReadLine();

Console.WriteLine("Target Character:");
char TargetChar = Char.Parse(Console.ReadLine());
TargetChar = Char.ToUpper(TargetChar);

int Result = countCharacters(UserString, TargetChar);
Console.WriteLine($"You string had {Result} Target Chars in it");