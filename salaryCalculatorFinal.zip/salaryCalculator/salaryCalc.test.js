import { paySalary } from "./salaryCalc"
import {vi, beforeEach, it, expect} from "vitest"
import { Window } from 'happy-dom'
import fs from 'fs';
import path from 'path';

const htmlDocPath = path.join(process.cwd(), 'salaryCalc.html');
const htmlDocumentContent = fs.readFileSync(htmlDocPath).toString();

const window = new Window();
const document = window.document;
vi.stubGlobal('document', document)

beforeEach(() => {
	document.body.innerHTML = '';
	document.write(htmlDocumentContent);
})

it("should return 'employee gross pay: 300' at 30 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 30

    document.getElementById("timeSheets").value = 35
    document.getElementById("FICA").value = 19268.98

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 300")
})

it("should return 'employee gross pay: 415' at 41 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 41

    document.getElementById("timeSheets").value = 35
    document.getElementById("FICA").value = 19268.98

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 415")
})

it("should return 'employee gross pay: 0' at 0 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 0

    document.getElementById("timeSheets").value = 35
    document.getElementById("FICA").value = 19268.98

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 0")
})

it("should return 'employee gross pay: 400' at 40 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 40

    document.getElementById("timeSheets").value = 35
    document.getElementById("FICA").value = 19268.98

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 400")
})

it("should return 'employee gross pay: 925' at 75 hours", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 75

    document.getElementById("timeSheets").value = 35
    document.getElementById("FICA").value = 19268.98

    paySalary()
    const salary = document.getElementById("pay").innerHTML
    expect(salary).toBe("Employee Gross Pay: 925")
})

it("should return the name element as 'Employee name: [inputted name]'", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 30

    document.getElementById("timeSheets").value = 35
    document.getElementById("FICA").value = 19268.98

    paySalary()
    const displayName = document.getElementById("name").innerHTML
    expect(displayName).toBe("Employee Name: dave")
})

it("should not find an error in the errorReport element when there is no error", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 30

    document.getElementById("timeSheets").value = 35
    document.getElementById("FICA").value = 19268.98

    paySalary()
    const errorReport = document.getElementById("errorReport").innerHTML
    expect(errorReport).toBe('')
})

it("should throw the custom error 'incorrect FICA value' if the FICA value is not exactly 19268.98", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 30

    document.getElementById("timeSheets").value = 35
    document.getElementById("FICA").value = 19268.99

    paySalary()
    const errorReport = document.getElementById("errorReport").innerHTML
    expect(errorReport).toBe("Error: Incorrect FICA value")
})

it("should throw the custom error 'missing time sheets' when there are less than 35 time sheets", () => {
    document.getElementById("name").value = "dave"
    document.getElementById("hours").value = 30
    
    document.getElementById("timeSheets").value = 34
    document.getElementById("FICA").value = 19268.98

    paySalary()
    const errorReport = document.getElementById("errorReport").innerHTML
    expect(errorReport).toBe("Error: missing timesheets")
})

